# SneakWash - GitHub Pages

Bu klasör GitHub Pages üzerinde ücretsiz yayınlanabilecek hazır SneakWash sitesi içerir.

## Yayına alma

1. GitHub'da yeni bir repository oluştur.
2. `index.html`, `style.css` ve `sneakwash-urun.webp` dosyalarını yükle.
3. Repository > Settings > Pages bölümüne gir.
4. Source olarak `Deploy from a branch` seç.
5. Branch olarak `main` ve klasör olarak `/root` seç.
6. Save'e bas.
7. GitHub sana `https://kullaniciadiniz.github.io/repo-adi/` şeklinde bir adres verecek.

## WhatsApp
Site üzerindeki sipariş butonu 0538 949 63 36 numarasına yönlendirilmiştir.

Fiyatı daha sonra eklemek istersen `index.html` içindeki sipariş bölümünü değiştirebilirsin.
